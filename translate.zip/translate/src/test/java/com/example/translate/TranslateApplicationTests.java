package com.example.translate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranslateApplicationTests {

	@Test
	void contextLoads() {
	}

}
